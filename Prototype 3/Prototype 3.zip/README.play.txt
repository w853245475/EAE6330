	
	Use WASD key to move around, Hold Shift to move faster, Hold Space to go up, Press ESC to quit